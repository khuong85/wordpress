<?php
/**
 * Content Wrappers
 */
?>

<div id="primary" class="<?php yit_sidebar_layout() ?>">
    <div class="container group">
	    <div class="row">
	        <?php

                do_action( 'yit_before_content' ); ?>